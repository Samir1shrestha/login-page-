Firstly
you need to install the xampp software. download link: https://www.apachefriends.org/download.html 

- After downloading install it to the c: drive.
- After installing open the xampp and start the apache and mysql.

Second
- Extract the zip file to the location c:> xampp > htdocs

third
-Make the database by clicking on the admin button of MySQL in xampp.
-your database dashboard will open.
- click on New 
- Create the database name as login.
- Name the table name as registration. , choose num of columins = 8. , press on Go button.
- type the following keyword:

name	       type	length     index		   A_I
id	     int		  primary    		[ tick it]
fname	     varchar	50	
mname	     varchar	50	
lname	     varchar	50
email	     varchar	50
password     varchar	20
cpasswor     varchar	20
number	     Bigint	10

-click on save buttton.



Lastly,
Type on the address bar directly : localhost/login 



CONGRATULATION!!!
YOU CAN ENJOY YOUR SITE.

